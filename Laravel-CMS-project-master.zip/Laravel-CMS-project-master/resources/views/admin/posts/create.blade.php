@extends('layouts.admin')


@section('content')

<h1>Create Post</h1>


@stop