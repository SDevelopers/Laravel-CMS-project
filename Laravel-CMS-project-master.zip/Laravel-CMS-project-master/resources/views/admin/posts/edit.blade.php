@extends('layouts.admin')


@section('content')

<h1>Edit Post</h1>


@stop